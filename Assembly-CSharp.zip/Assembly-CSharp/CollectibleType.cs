public enum CollectibleType
{
	HeadmasterTape = 0,
	BasementTape = 1,
	Manga = 2,
	Tape = 3,
	Key = 4,
	Panty = 5
}
