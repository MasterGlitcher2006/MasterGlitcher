public enum BucketContentsType
{
	Water = 0,
	Gas = 1,
	Weights = 2
}
