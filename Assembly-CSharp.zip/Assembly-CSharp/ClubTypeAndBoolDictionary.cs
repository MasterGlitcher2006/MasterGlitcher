using System;

[Serializable]
public class ClubTypeAndBoolDictionary : SerializableDictionary<ClubType, bool>
{
}
