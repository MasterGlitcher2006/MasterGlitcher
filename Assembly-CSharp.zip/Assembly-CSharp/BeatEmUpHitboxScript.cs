using UnityEngine;

public class BeatEmUpHitboxScript : MonoBehaviour
{
	public int AttackID;

	public float Damage;

	public bool Enemy;

	public bool Heavy;

	public bool Super;
}
