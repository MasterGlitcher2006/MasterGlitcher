using UnityEngine;

[AddComponentMenu("Image Effects/Amplify Motion Object")]
public class AmplifyMotionObject : AmplifyMotionObjectBase
{
}
