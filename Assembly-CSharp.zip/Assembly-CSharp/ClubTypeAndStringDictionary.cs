using System;

[Serializable]
public class ClubTypeAndStringDictionary : SerializableDictionary<ClubType, string>
{
}
