using System;

[Serializable]
public class ClubTypeHashSet : SerializableHashSet<ClubType>
{
}
