using UnityEngine;

public class CardiganScript : MonoBehaviour
{
	public SkinnedMeshRenderer MyRenderer;
}
