public enum AudioType
{
	Effect = 0,
	Music = 1,
	Voice = 2
}
