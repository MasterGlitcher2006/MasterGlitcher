namespace AnimationOrTween
{
	[DoNotObfuscateNGUI]
	public enum EnableCondition
	{
		DoNothing = 0,
		EnableThenPlay = 1,
		IgnoreDisabledState = 2
	}
}
