namespace AnimationOrTween
{
	[DoNotObfuscateNGUI]
	public enum DisableCondition
	{
		DisableAfterReverse = -1,
		DoNotDisable = 0,
		DisableAfterForward = 1
	}
}
