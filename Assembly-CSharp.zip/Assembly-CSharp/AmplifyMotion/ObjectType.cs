namespace AmplifyMotion
{
	public enum ObjectType
	{
		None = 0,
		Solid = 1,
		Skinned = 2,
		Cloth = 3,
		Particle = 4
	}
}
