namespace AmplifyMotion
{
	public enum Quality
	{
		Mobile = 0,
		Standard = 1,
		Standard_SM3 = 2,
		SoftEdge_SM3 = 3
	}
}
